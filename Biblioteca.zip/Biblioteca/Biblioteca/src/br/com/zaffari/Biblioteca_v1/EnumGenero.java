package br.com.zaffari.Biblioteca_v1;

public class EnumGenero {
	enum GenerosEnum {
		 Ficção, Drama, Romance, Ação, Comédia, Terror;

		boolean contains(GenerosEnum categoria) {
			// TODO Auto-generated method stub
			return true;
		}
	 }
	
}
